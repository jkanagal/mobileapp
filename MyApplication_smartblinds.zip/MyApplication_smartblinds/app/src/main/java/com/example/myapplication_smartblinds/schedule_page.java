package com.example.myapplication_smartblinds;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class schedule_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_page);
    }
}